from src.domain.knowledge_graph.graph_index import GraphIndex
from src.domain.knowledge_graph.knowledge_graph import KnowledgeGraph
from src.domain.knowledge_graph.knowledge_node import KnowledgeNode
from src.domain.knowledge_graph.knowledge_edge import KnowledgeEdge

graph = KnowledgeGraph(
    nodes=[
        KnowledgeNode(
            id="person:muhammad",
            type="PERSON",
            data={"name":"Muhammad"}
        ),
        KnowledgeNode(
            id="event:badr",
            type="EVENT",
            data={"title":"Battle of Badr"}
        )
    ],
    edges=[
        KnowledgeEdge(
            source="person:muhammad",
            target="event:badr",
            relation="participated_in"
        )
    ]
)

index = GraphIndex()
index.build(graph)

assert index.get_node("person:muhammad").data["name"] == "Muhammad"
assert len(index.get_nodes_by_type("PERSON")) == 1
assert len(index.outgoing("person:muhammad")) == 1
assert len(index.incoming("event:badr")) == 1

print("GraphIndex OK")


