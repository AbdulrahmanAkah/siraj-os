class ImagePromptGenerator:

    def generate(self, scenes):

        prompts=[]

        for scene in scenes:

            narration=scene.narration.replace("\n"," ")

            if len(narration)>700:
                narration=narration[:700]

            prompt=f"""
Ultra realistic cinematic historical documentary.

Scene:
{scene.title}

Narration:
{narration}

Requirements:

- historically accurate
- realistic humans
- realistic clothing
- realistic architecture
- dramatic cinematic lighting
- volumetric light
- ultra detailed
- high realism
- 8k
- masterpiece
- documentary photography
"""

            prompts.append({

                "scene_index":scene.index,

                "prompt":" ".join(prompt.split()),

                "negative_prompt":"low quality, blurry, text, watermark, logo, cartoon, anime, duplicate, deformed"

            })

        return prompts


__all__=["ImagePromptGenerator"]


