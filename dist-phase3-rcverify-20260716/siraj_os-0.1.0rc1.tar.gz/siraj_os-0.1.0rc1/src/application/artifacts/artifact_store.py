from src.application.artifacts.artifact import Artifact, ArtifactType


class ArtifactStore:

    def __init__(self):
        self._items: dict[ArtifactType, Artifact] = {}

    def put(self, artifact: Artifact):
        self._items[artifact.type] = artifact

    def get(self, artifact_type: ArtifactType):
        item = self._items.get(artifact_type)
        return None if item is None else item.value

    def has(self, artifact_type: ArtifactType):
        return artifact_type in self._items

    def all(self):
        return {
            k.value: v.value
            for k, v in self._items.items()
        }


__all__ = ["ArtifactStore"]


