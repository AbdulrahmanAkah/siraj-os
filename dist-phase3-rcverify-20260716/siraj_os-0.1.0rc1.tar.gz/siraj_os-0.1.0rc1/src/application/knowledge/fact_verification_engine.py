from dataclasses import dataclass


@dataclass
class VerifiedClaim:

    text:str

    verified:bool

    confidence:float

    reason:str


class FactVerificationEngine:

    def verify(

        self,

        graph,

    ):

        node_types=getattr(

            graph.index,

            "nodes_by_type",

            {}

        )

        claims=node_types.get("CLAIM",[])

        sources=node_types.get("SOURCE",[])

        has_source=len(sources)>0

        results=[]

        for claim in claims:

            d=claim.data

            text=d["text"] if isinstance(d,dict) else getattr(d,"text","")

            results.append(

                VerifiedClaim(

                    text=text,

                    verified=has_source,

                    confidence=1.0 if has_source else 0.25,

                    reason="supported by imported source" if has_source else "no source",

                )

            )

        return results


__all__=["VerifiedClaim","FactVerificationEngine"]


