from dataclasses import dataclass

@dataclass
class RelationshipRecord:

    source:str
    relation:str
    target:str

class RelationshipEngine:

    def build(self,graph):

        records=[]

        for edge in getattr(graph,"edges",[]):

            if isinstance(edge,dict):

                records.append(
                    RelationshipRecord(
                        source=edge.get("source",""),
                        relation=edge.get("relation",""),
                        target=edge.get("target","")
                    )
                )

            else:

                records.append(
                    RelationshipRecord(
                        source=getattr(edge,"source",""),
                        relation=getattr(edge,"relation",""),
                        target=getattr(edge,"target","")
                    )
                )

        return records

__all__=["RelationshipRecord","RelationshipEngine"]


